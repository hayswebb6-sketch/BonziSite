from winotify import Notification
import tkinter as tk
import subprocess
from tkinter import PhotoImage
import webbrowser
import random
import ctypes



browsers=[
    "https://roulette-kejd.onrender.com",
    "https://www.google.com",
    "https://www.bing.com",
    "https://peak.wiki.gg",
    "https://www.geoguessr.com",
    "https://www.duckduckgo.com",
    "https://www.youtube.com/watch?v=AyOqGRjVtls",
    "https://www.chatgpt.com",
    "https://www.reddit.com",
    "https://www.ebay.com",
    "https://www.amazon.com",
]
apps = [
    "notepad.exe",
    "calc.exe",
    "explorer.exe",
]

def teleport():
    time=random.randint(3000,7000)
    x=random.randint(0,page_width-400)
    y=random.randint(0, page_height-300)
    window.geometry(f"400x300+{x}+{y}")
    window.after(time, teleport)

def choose():
    time=random.randint(10000,30000)
    random.choice(actions)[1]()
    window.after(time, choose)

def open_app():
    chosen_app=random.choice(apps)
    subprocess.Popen([chosen_app])


def open_browser():
    chosen_browser=random.choice(browsers)
    webbrowser.open(chosen_browser)


def hide_mouse():
    ctypes.windll.user32.ShowCursor(False)
    window.after(5000, show_mouse)

def show_mouse():
    ctypes.windll.user32.ShowCursor(True)

def x_pressed():
    number=random.randint(2,5)
    for n in range(number):
        action=random.choice(actions)
        action[1]()
    toast=Notification(app_id="Bonzi Buddy",
                   title="Bonzi Buddy",
                   msg="How dare you try to close me.",
)
    toast.show()

actions=[
    ("Open App", open_app),
    ("Open Browser", open_browser),
    ("Hide Mouse", hide_mouse),
]

window = tk.Tk()

window.title("Bonzi Buddy")

page_width=window.winfo_screenwidth()

page_height=window.winfo_screenheight()

window.attributes("-topmost", True)

window.resizable(False, False)

bonzi_image=PhotoImage(file="Designer.png")

bonzi_image=bonzi_image.subsample(4, 4)

bonzi=tk.Label(window, image=bonzi_image)

bonzi.pack()

window.geometry("400x300")

window.iconphoto(False, PhotoImage(file="bonzi.png"))

window.protocol("WM_DELETE_WINDOW", x_pressed)

teleport()
choose()
window.mainloop()